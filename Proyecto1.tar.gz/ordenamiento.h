#include <stdio.h>
#include <stdlib.h>

int * merge(int arreglo1[], int arreglo2[], int tam1, int tam2);

void quicksort_rec(int arreglo[], int lim_izq, int lim_der);

void quicksort(int arreglo[], int tam);

int * merge_h(int arreglo[], int ini, int med, int fin);