#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "ordenamiento.h"

int Tomar_Tiempo();
